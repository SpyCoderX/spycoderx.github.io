const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d'); // This is your drawing tool
const imageList = ["player.svg","enemy.svg","projectile.svg"]

let imageLibrary = {};
imageList.forEach(val => {
    const img = new Image();
    img.src = val;
    const name = val.split(".")[0];
    imageLibrary[name] = img;
})

class Vector {
    x = 0;
    y = 0;
    constructor(a=null,b=null) {
        if (a instanceof Vector) {
            this.x = a.x;
            this.y = a.y;
        } else if (a != null && b != null) {
            this.x = a;
            this.y = b;
        } else if (a != null) {
            this.x = a;
            this.y = a;
        } else {
            this.x = 0;
            this.y = 0;
        }
    }
    add(other) {
        if (!(other instanceof Vector)) {
            other = new Vector(other);
        }
        return new Vector(this.x+other.x,this.y+other.y);
    }
    sub(other) {
        if (!(other instanceof Vector)) {
            other = new Vector(other);
        }
        return new Vector(this.x-other.x,this.y-other.y);
    }
    mul(other) {
        if (!(other instanceof Vector)) {
            other = new Vector(other);
        }
        return new Vector(this.x*other.x,this.y*other.y);
    }
    div(other) {
        if (!(other instanceof Vector)) {
            other = new Vector(other);
        }
        return new Vector(this.x/other.x,this.y/other.y);
    }

    addMe(other) {
        if (!(other instanceof Vector)) {
            other = new Vector(other);
        }
        this.x += other.x;
        this.y += other.y;
        return this;
    }
    subMe(other) {
        if (!(other instanceof Vector)) {
            other = new Vector(other);
        }
        this.x -= other.x;
        this.y -= other.y;
        return this;
    }
    mulMe(other) {
        if (!(other instanceof Vector)) {
            other = new Vector(other);
        }
        this.x *= other.x;
        this.y *= other.y;
        return this;
    }
    divMe(other) {
        if (!(other instanceof Vector)) {
            other = new Vector(other);
        }
        this.x /= other.x;
        this.y /= other.y;
        return this;
    }
    setMe(other) {
        if (!(other instanceof Vector)) {
            other = new Vector(other);
        }
        this.x = other.x;
        this.y = other.y;
        return this;
    }
    copy() {
        return new Vector(this);
    }

    static fromPolar(radius, theta) {
        return new Vector(Math.cos(theta)*radius,Math.sin(theta)*radius)
    }

    angleTo(other) {
        return Math.atan2(
            other.y - this.y,
            other.x - this.x
        )
    }
    distance(other) {
        return Math.sqrt(
            (other.y - this.y)**2+
            (other.x - this.x)**2
        )
    }
}

class Bullet {
    vel = new Vector();
    pos = new Vector();
    size = new Vector(25);
    rot = 0;
    constructor(_pos,_rot) {
        this.pos = _pos.copy();
        this.rot = _rot;
    }
}

class Player {
    inputMap = new Vector();
    vel = new Vector();
    pos = new Vector();
    size = new Vector(100);
    rot = 0;
}
class Zombie {
    pos = new Vector();
    size = new Vector(100);
    rot = 0;
    HP = 10;
    constructor(_pos) {
        this.pos = _pos.copy();
    }
}

class Game {
    center = new Vector();
    camera = new Vector();
    mouse = new Vector();
    followMouse = new Vector();
    player = new Player();
    keys = {};
    ticks = 0;

    update() {
        this.ticks += 1;
        if (this.ticks%30 == 0) {
            zombies.push(new Zombie(this.player.pos.add(Vector.fromPolar(600,Math.random()*Math.PI*2))))
        } 
        this.camera.mulMe(0.9);
        this.camera.addMe(this.player.pos.mul(0.1));
        this.followMouse.mulMe(0.8);
        this.followMouse.addMe(this.mouse.mul(0.2));

        this.player.inputMap = new Vector(this.getKey("d") - this.getKey("a"), this.getKey("s") - this.getKey("w"));
        this.player.vel.addMe(this.player.inputMap);
        this.player.vel.mulMe(0.8);
        this.player.pos.addMe(this.player.vel);

        if (this.getKey("mouse")) {
            bullets.push(new Bullet(this.player.pos,this.player.rot));
        }

        this.player.rot = Math.atan2(
            this.followMouse.y,
            this.followMouse.x
        )
        
        for (const zomb of zombies) {
            zomb.rot = zomb.pos.angleTo(this.player.pos);
            zomb.pos.addMe(Vector.fromPolar(1,zomb.rot))
        }

        for (let j = 0; j < bullets.length; j++) {
            const bullet = bullets[j];
            bullet.pos.addMe(Vector.fromPolar(25,bullet.rot))
            let del = false;
            for (let i = 0; i < zombies.length; i++) {
                const zomb = zombies[i];
                if (bullet.pos.distance(zomb.pos) < bullet.size.x + zomb.size.x) {
                    zombies.splice(i,1);
                    i--;
                    del = true;
                    break;
                }
            }
            if (bullet.pos.distance(this.player.pos) > 1000) {
                del = true;
            }
            if (del == true) {
                bullets.splice(j,1);
                j--;
            }
        }
        
    }
    getKey(key) {
        return this.keys[key] ?? false;
    }


    draw(image,location,size,rot=0,upwards=false) {
        ctx.save();
        const offset = this.center.div(2).add(location).sub(this.camera);
        ctx.translate(offset.x,offset.y);
        if (upwards) {
            ctx.rotate(rot+Math.PI/2);
        } else {
            ctx.rotate(rot);
        }
        const halfSize = size.div(2);
        ctx.drawImage(image,-halfSize.x,-halfSize.y,size.x,size.y);
        ctx.restore();
    }

    onMouseMove(event) {
        const rect = canvas.getBoundingClientRect();

        this.mouse.setMe(
            new Vector(
                event.clientX - rect.left - this.center.x / 2 - (this.player.pos.x - this.camera.x),
                event.clientY - rect.top - this.center.y / 2 - (this.player.pos.y - this.camera.y)
            )
        );

        
    }
    onKeyDown(event) {
        this.keys[event.key] = true;
    }
    onKeyUp(event) {
        this.keys[event.key] = false;
    }
    onMouseDown(event) {
        this.keys["mouse"] = true;
    }
    onMouseUp(event) {
        this.keys["mouse"] = false;
    }
}

game = new Game();


const zombies = [];
for (let i = 0; i < 10; i++) {
    zombies.push(new Zombie(Vector.fromPolar(600,Math.random()*Math.PI*2)))
}

const bullets = [];

// Set dimensions

resizeCanvas()

function resizeCanvas() {
    canvas.width = 0.64 * window.innerWidth;
    canvas.height = 0.48 * window.innerWidth;
    game.center = new Vector(canvas.width,canvas.height);
}

window.addEventListener("resize",resizeCanvas);

window.addEventListener("mousemove",(e) => game.onMouseMove(e));
window.addEventListener("mousedown",(e) => game.onMouseDown(e));
window.addEventListener("mouseup",(e) => game.onMouseUp(e));

window.addEventListener("keydown",(e) => game.onKeyDown(e));
window.addEventListener("keyup",(e) => game.onKeyUp(e));





function gameLoop() {
    // 1. Clear the previous frame
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = '#2e3b2e';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    game.update();
    game.draw(imageLibrary["player"],game.player.pos,game.player.size,game.player.rot,true);
    zombies.forEach(zomb => {
        game.draw(imageLibrary["enemy"],zomb.pos,zomb.size,zomb.rot,true)
    })
    bullets.forEach(bullet => {
        game.draw(imageLibrary["projectile"],bullet.pos,bullet.size,bullet.rot,false)
    })

    // 2. Update object positions (e.g., player.x += player.speed)
    //update();

    // 3. Draw objects to the canvas
    //draw();

    // 4. Call the loop again for the next frame
    requestAnimationFrame(gameLoop);
}

gameLoop();